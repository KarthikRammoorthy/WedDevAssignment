<?php
/**
 * Created by PhpStorm.
 * User: karthikrammoorthy
 * Date: 16/05/18
 * Time: 7:12 PM
 */

session_start();

if (isset($_SESSION['user']) != "") {
    header("Location: home.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <?php /** View port for responsive design*/ ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php /** Link External CSS file to this index.pho file */ ?>
    <link href="css/stylesheet.css" type="text/css" rel="stylesheet"/>
    <title> Dalhousie eShopping</title>
</head>
<body>
<?php /** Header Part */ ?>
<header id="header-part" class="grid">
    <div class="background-image"></div>
    <div class="content-wrap">
        <h1>Dalhousie eShopping</h1>
        <nav id="nav-class">
            <ul>
                <li>
                    <a href="#">Buy</a>
                </li>
                <li>
                    <a href="#">Shop</a>
                </li>
                <li>
                    <a href="#">Help</a>
                </li>
                <li>
                    <a href="./register.php" id="signup-launcher" class="login-link">Signup</a>
                </li>
                <li>
                    <a href="./login.php" id="login-launcher" class="login-link">Login</a>
                </li>
            </ul>
        </nav>
    </div>
</header>
<?php /** Main Area  */ ?>
<main id="main-part">
    <?php /** Section A  */ ?>
    <section id="sectiona" class="grid">
        <div class="content-wrap">
            <div class="content-title">
                <h2>Everything you need in one place</h2>
            </div>
            <div class="content-text">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus ad aliquam aperiam at blanditiis
                    corporis, deserunt dolorem doloremque dolorum est eveniet expedita hic incidunt itaque maxime
                    mollitia
                    natus
                    nulla obcaecati omnis quam quibusdam quidem ratione repudiandae ullam ut voluptate voluptatibus!</p>
            </div>
        </div>
    </section>
    <?php /** Section B  */ ?>
    <section id="sectionb" class="grid">
        <ul>
            <li>
                <div class="card">
                    <img src="./Images/blur-capacitors-chip-825259.jpg" alt="">
                    <div class="card-content">
                        <h3 class="card-title">Electronics</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet aperiam distinctio ducimus, ea
                            impedit magni minima quo rerum sapiente voluptatibus.</p>
                    </div>
                </div>
            </li>
            <li>
                <div class="card">
                    <img src="./Images/agriculture-basket-beets-533360.jpg" alt="">
                    <div class="card-content">
                        <h3 class="card-title">Straight from the Farms</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet aperiam distinctio ducimus, ea
                            impedit magni minima quo rerum sapiente voluptatibus.</p>
                    </div>
                </div>
            </li>
            <li>
                <div class="card">
                    <img src="./Images/blur-business-clothes-325876.jpg" alt="">
                    <div class="card-content">
                        <h3 class="card-title">Suit Up!</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet aperiam distinctio ducimus, ea
                            impedit magni minima quo rerum sapiente voluptatibus.</p>
                    </div>
                </div>
            </li>
        </ul>
    </section>
    <?php /** Section C  */ ?>
    <section id="sectionc" class="grid">
        <div class="content-wrap">
            <h2 class="content-title">
                Buy/Sell
            </h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet delectus dolorum ipsam non odit quam quia
                temporibus! Accusamus distinctio enim eum eveniet iste iure laboriosam laborum magnam, modi repellat?
                Harum.</p>
        </div>
    </section>
    <?php /** Section D  */ ?>
    <section id="sectiond" class="secondary-grid">
        <div>
            <h4 class="content-title">
                Get to know us
            </h4>
            <p>Lorem ipsum dolor.</p>
            <p>Lorem ipsum dolor.</p>
            <p>Lorem ipsum dolor.</p>
        </div>
        <div>
            <h4 class="content-title">
                Make money with us
            </h4>
            <p>Lorem ipsum dolor.</p>
            <p>Lorem ipsum dolor.</p>
            <p>Lorem ipsum dolor.</p>
        </div>
        <div>
            <h4 class="content-title">
                Payment Products
            </h4>
            <p>Lorem ipsum dolor.</p>
            <p>Lorem ipsum dolor.</p>
            <p>Lorem ipsum dolor.</p>
        </div>
        <div>
            <h4 class="content-title">
                Let us help you
            </h4>
            <p>halifaxeshopping@outlook.com</p>
            <p>Lorem ipsum dolor.</p>
            <p>Lorem ipsum dolor.</p>
        </div>
    </section>
</main>
<footer id="footer-part" class="grid">
    <div>Chennai IT Solutions</div>
    <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, iure.</div>
</footer>
</body>
</html>
