<?php
/**
 * Created by PhpStorm.
 * User: karthikrammoorthy
 * Date: 03/06/18
 * Time: 11:18 AM
 */

$db_host = "db.cs.dal.ca";
$db_name = "rammoorthy";
$db_user = "rammoorthy";
$db_pass = "B00790749";


try {
    $conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}

catch(PDOException $e)
{
     $e->getMessage();
}
?>