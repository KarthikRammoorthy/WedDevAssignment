<?php
/**
 * Created by PhpStorm.
 * User: karthikrammoorthy
 * Date: 20/05/18
 * Time: 4:46 PM
 */

ob_start();
session_start();

require_once 'loginprocess.php';

?>

<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <?php /** View port for responsive design*/ ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php /** Link External CSS file to this index.pho file */ ?>
    <link href="css/stylesheet.css" type="text/css" rel="stylesheet"/>
    <title> Dalhousie eShopping</title>
</head>
<body>
<header id="header-part" class="grid">
    <div class="background-image"></div>
    <div class="content-wrap">
        <h1>Dalhousie eShopping</h1>
        <nav id="nav-class">
            <ul>
                <li>
                    <a href="#">Buy</a>
                </li>
                <li>
                    <a href="#">Shop</a>
                </li>
                <li>
                    <a href="#">Sell</a>
                </li>
                <li>
                    <a href="./register.php" id="signup-launcher" class="login-link">Signup</a>
                </li>
                <li>
                    <a href="./index.php" class="login-link">Home</a>
                </li>
            </ul>
        </nav>
    </div>
</header>
<?php /** Main Area  */ ?>
<main id="main-part">
<div id="login-form">
    <div class="content-wrap">
        <h1>Login</h1>
        <form method="post" name="frmRegister" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"
              class="grid">
            <div class="container">

                <?php
                if (isset($errMSG)) {

                    ?>

                    <label id="errLabelMessage" class="codered">Error</label>
                    <label id="errMessage" class="codered"> <?php echo $errMSG; ?></label>

                    <?php
                }
                ?>
                <label id="lblemailid">Email ID</label>
                <input type="text" name="email" value = "<?php if(isset($_POST['firstname'])) { echo  htmlentities($_POST['email']); } ?>" placeholder="Enter Email id"/>
                <?php
                if (isset($errEmailMessage)) {

                    ?>

                    <label id="errLabelEmail" class="codered"> Error </label>
                    <label id="errEmail" class="codered"> <?php echo $errEmailMessage; ?></label>

                    <?php
                }
                ?>
                <label id="lbluserid">Password</label>
                <input type="password" name="password" value = "<?php if(isset($_POST['firstname'])) { echo  htmlentities($_POST['password']); } ?>" placeholder="Enter Password"/>
                <?php
                if (isset($errPasswordMessage)) {

                    ?>

                    <label id="errLabelPassword" class="codered"> Error </label>
                    <label id="errPassword" class="codered"> <?php echo $errPasswordMessage; ?></label>

                    <?php
                }
                ?>
                <input type="submit" name="login" value="Submit"/>
            </div>
        </form>
    </div>
</div>
</main>
<footer id="footer-part" class="grid">
    <div>Chennai IT Solutions</div>
    <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, iure.</div>
</footer>
</body>
</html>