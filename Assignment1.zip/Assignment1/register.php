<?php
/**
 * Created by PhpStorm.
 * User: karthikrammoorthy
 * Date: 20/05/18
 * Time: 4:52 PM
 */
ob_start();
session_start();

require_once 'registerprocess.php';

?>
<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <?php /** View port for responsive design*/ ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php /** Link External CSS file to this index.pho file */ ?>
    <link href="css/stylesheet.css" type="text/css" rel="stylesheet"/>
    <title> Dalhousie eShopping</title>
</head>
<body>
<header id="header-part" class="grid">
    <div class="background-image"></div>
    <div class="content-wrap">
        <h1>Dalhousie eShopping</h1>
        <nav id="nav-class">
            <ul>
                <li>
                    <a href="#">Buy</a>
                </li>
                <li>
                    <a href="#">Shop</a>
                </li>
                <li>
                    <a href="#">Sell</a>
                </li>
                <li>
                    <a href="#">Help</a>
                </li>
                <li>
                    <a href="./index.php" class="login-link">Home</a>
                </li>
            </ul>
        </nav>
    </div>
</header>
<?php /** Main Area  */ ?>
<main id="main-part">
    <div id="login-form">
        <div class="content-wrap">
            <h1>Register</h1>
            <form method="post" name="frmRegister" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"
                  class="grid">
                <div class="container">
                    <?php
                    if (isset($errMSG)) {

                        ?>

                    <label id="message"></label>
                        <label id="errMsg" class="codered"> <?php echo $errMSG; ?></label>

                        <?php
                    }
                    ?>
                    <label id="lblFirstName">First Name </label>
                    <input type="text" name="firstname" value = "<?php if(isset($_POST['firstname'])) { echo  htmlentities($_POST['firstname']); } ?>"   placeholder="Enter First Name"/>
                    <?php
                    if (isset($errFirstNameMessage)) {

                        ?>

                        <label id="errLabelFirstName"> Error </label>
                        <label id="errFirstName" class="codered"> <?php echo $errFirstNameMessage; ?></label>

                        <?php
                    }
                    ?>
                    <label id="lblLastName">Last Name</label>
                    <input type="text" name="lastname" value = "<?php if(isset($_POST['lastname'])) { echo  htmlentities($_POST['lastname']); } ?>" placeholder="Enter Last Name"/>
                    <?php
                    if (isset($errLastNameMessage)) {

                        ?>

                        <label id="errLabelLastName">Error</label>
                        <label id="errLabelLastName" class="codered"> <?php echo $errLastNameMessage; ?></label>

                        <?php
                    }
                    ?>
                    <label id="lblEmail">Email</label>
                    <input type="text" name="email"  value = "<?php if(isset($_POST['email'])) { echo  htmlentities($_POST['email']); } ?>" placeholder="Enter Email Address"/>
                    <?php
                    if (isset($errEmailMessage)) {

                        ?>

                        <label id="errLabelEmail">Error</label>
                        <label id="errEmail" class="codered"> <?php echo $errEmailMessage; ?></label>

                        <?php
                    }
                    ?>
                    <label id="lblPassword">Password</label>
                    <input type="password"  name="password" value = "<?php if(isset($_POST['password'])) { echo  htmlentities($_POST['password']); } ?>" placeholder="Enter Password"/>
                    <?php
                    if (isset($errPasswordMessage)) {

                        ?>

                        <label id="errLabelPassword">Error</label>
                        <label id="errPassword" class="codered"> <?php echo $errPasswordMessage; ?></label>

                        <?php
                    }
                    ?>
                    <label id="lblReenterPwd">Reenter Password</label>
                    <input type="password" name="reenterpwd" value = "<?php if(isset($_POST['reenterpwd'])) { echo  htmlentities($_POST['reenterpwd']); } ?>"  placeholder="Reenter Password"/>
                    <?php
                    if (isset($errRePwdMessage)) {

                        ?>

                        <label id="errLabelRePwd">Error</label>
                        <label id="errRePwd" class="codered"> <?php echo $errRePwdMessage; ?></label>

                        <?php
                    }
                    ?>
                    <label id="lblAddress">Address</label>
                    <input type="text" name="address" value = "<?php if(isset($_POST['address'])) { echo  htmlentities($_POST['address']); } ?>"  placeholder="format: ## Street Name"/>
                    <?php
                    if (isset($errAddressMessage)) {

                        ?>

                        <label id="errLabelAddress">Error</label>
                        <label id="errAddress" class="codered"> <?php echo $errAddressMessage; ?></label>

                        <?php
                    }
                    ?>
                    <label id="lblPinCode">Pin Code</label>
                    <input type="text" name="pincode" value = "<?php if(isset($_POST['pincode'])) { echo  htmlentities($_POST['pincode']); } ?>" placeholder="format: ### ###"/>
                    <?php
                    if (isset($errPincodeMessage)) {

                        ?>

                        <label id="errLabelPincode">Error</label>
                        <label id="errPincode" class="codered"> <?php echo $errPincodeMessage; ?></label>

                        <?php
                    }
                    ?>
                    <input type="submit" name="submit" value="Register"/>
                </div>
            </form>
        </div>
    </div>
</main>

<footer id="footer-part" class="grid">
    <div>Chennai IT Solutions</div>
    <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, iure.</div>
</footer>
</body>
</html>
