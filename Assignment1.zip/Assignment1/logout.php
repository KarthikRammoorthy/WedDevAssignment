<?php
/**
 * Created by PhpStorm.
 * User: karthikrammoorthy
 * Date: 03/06/18
 * Time: 10:08 PM
 */
session_start();

if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['user']);
    header("Location: index.php");
    exit;
}
