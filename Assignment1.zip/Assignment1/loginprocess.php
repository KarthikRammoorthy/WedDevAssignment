<?php
/**
 * Created by PhpStorm.
 * User: karthikrammoorthy
 * Date: 04/06/18
 * Time: 10:20 AM
 */

require_once 'dbconnect.php';

// if session is set direct to home
if (isset($_SESSION['user']) != "") {
    header("Location: home.php");
    exit;
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = htmlentities($data);
    return $data;
}

try {

    if (isset($_POST['login'])) {
        $email = test_input($_POST["email"]);
        $password = test_input($_POST["password"]);
        //$errMSG = $errPasswordMessage = $errEmailMessage = "";
        $valid = true;

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errEmailMessage = "Please enter valid emailid";
            $valid = false;
        }
        if (empty($password)) {
            $errPasswordMessage = "Password cannot be empty";
            $valid = false;
        }


        if ($valid == true) {


            //$password = hash('sha256', $upass); // password hashing using SHA256

            $stmt = $conn->prepare("SELECT userid, email, userpassword FROM a1_users WHERE email = :email");
            $stmt->bindParam(":email", $email);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $count = $stmt->rowCount();
            if ($count == 1) {
                foreach ($result as $row) {
                    $rowresult = $row['userpassword'];
                    $rowuserid = $row['userid'];
                }
            }
            if ($count == 1 && password_verify($password, $rowresult)) {
                $_SESSION['user'] = $rowuserid;
                header("Location: home.php");
                exit;
            } elseif ($count == 1) {
                $errMSG = "EmailID / Password incorrect";
            } else $errMSG = "EmailID / Password incorrect";
        }
    }

    if (isset($_POST['signup'])) {

        header("Location: register.php");
        exit;
    }
}
catch (PDOException $e)
{
    $e->getMessage();
}
