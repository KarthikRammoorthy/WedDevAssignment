<?php
/**
 * Created by PhpStorm.
 * User: karthikrammoorthy
 * Date: 04/06/18
 * Time: 10:04 AM
 */

include_once 'dbconnect.php';

if (isset($_SESSION['user']) != "") {
    header("Location: home.php");
    exit;
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = htmlentities($data);
    return $data;
}

try {

    if (isset($_POST['submit'])) {

        $firstName = test_input($_POST["firstname"]);
        $lastName = test_input($_POST["lastname"]);
        $email = test_input($_POST["email"]);
        $address = test_input($_POST["address"]);
        $password = test_input($_POST["password"]);
        $reenterpwd = test_input($_POST["reenterpwd"]);
        $pincode = test_input($_POST["pincode"]);
        //$errMessage = "";
        //$errMSG = "";
        //$errTyp = "";
        //$errAddressMessage = $errFirstNameMessage = $errLastNameMessage = $errEmailMessage = $errPasswordMessage = $errRePwdMessage = $errPincodeMessage = "";

        $valid = true;

        if (empty($firstName) || (!preg_match("/^[a-zA-Z ]*$/", $firstName))) {
            $errFirstNameMessage = "Please enter valid first name";
            $valid = false;
        }
        if (empty($lastName) || (!preg_match("/^[a-zA-Z ]*$/", $lastName))) {
            $errLastNameMessage = "Please enter valid last name";
            $valid = false;
        }
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errEmailMessage = "Please enter valid email address";
            $valid = false;
        }

        //optional field
       if(strlen($address) > 0) {
           if ((!preg_match("/^[0-9]+$/", substr($address, 0, strpos($address, ' ')))) || (!preg_match("/^[a-zA-Z\s]+$/", substr($address, strpos($address, ' '))))) {
               $errAddressMessage = "Please enter address of format: ## StreetName";
               $valid = false;
           }
       }


        if (empty($password) || strlen($password) < 8) {
            $errPasswordMessage = "Please choose a password with minimum 8 characters";
            $valid = false;
        }
        if (empty($reenterpwd) || ($reenterpwd != $password)) {
            $errRePwdMessage = "Passwords donot match. Please try again";
            $valid = false;
        }

        //optional field
        if(strlen($pincode) >0) {
            if ((!preg_match("/^[0-9a-zA-Z]+$/", substr($pincode, 0, 2))) ||
                (!preg_match("/^[\s]+$/", substr($pincode, 3, 1))) ||
                (!preg_match("/^[0-9a-zA-Z]+$/", substr($pincode, 4, 6)))) {
                $errPincodeMessage = "Please enter pincode of format: ### ###";
                $valid = false;
            }
        }


        if ($valid == true) {
            // salting password
            $password = password_hash($password, PASSWORD_BCRYPT);

            // check email exist or not
            $stmt = $conn->prepare("SELECT email FROM a1_users WHERE email = :email");
            $stmt->bindParam(":email", $email);
            $stmt->execute();
            $count = $stmt->rowCount();

            if ($count == 0) { // if email is not found add user


                $stmts = $conn->prepare("INSERT INTO a1_users(firstname,lastname,email,userpassword,address,postalcode) VALUES(:firstname,:lastname,:email,:userpassword,:address,:postalcode)");
                $stmts->bindParam(":firstname", $firstName);
                $stmts->bindParam(":lastname", $lastName);
                $stmts->bindParam(":email", $email);
                $stmts->bindParam(":userpassword", $password);
                $stmts->bindParam(":address", $address);
                $stmts->bindParam(":postalcode", $pincode);

                $stmts->execute();//get result

                $user_id = $conn->lastInsertId();
                if ($user_id > 0) {
                    $_SESSION['user'] = $user_id; // set session and redirect to index page
                    if (isset($_SESSION['user'])) {
                        print_r($_SESSION);
                        header("Location: home.php");
                        exit;
                    }

                } else {
                    $errTyp = "danger";
                    $errMSG = "Something went wrong, try again";
                }

            } else {
                $errTyp = "warning";
                $errMSG = "Email is already used";
            }

        }
    }
}
catch (PDOException $e) {
    $e->getMessage();
}