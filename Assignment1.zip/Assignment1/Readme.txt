Assignment1
B00790749


Project Contents
1. dbconnect.php
2. home.php
3. index.php
4. login.php
5. loginprocess.php
6. logout.php
7. register.php
8. registerprocess.php
9. css folder conssisting of stylesheet.css
10. images folder consisting of 5 images. [ Downloaded from pexels]

SQL Table Creation



References

[1]"Grid CSS Responsive Website Layout - "Mobile First" Design", YouTube, 2018. [Online]. Available: https://www.youtube.com/watch?v=M3qBpPw77qo. [Accessed: 01- Jun- 2018].
[2]"CSS Grid Layout Crash Course", YouTube, 2018. [Online]. Available: https://www.youtube.com/watch?v=jV8B24rSN5o. [Accessed: 01- Jun- 2018].
[3]"laur1s/PHP-Registration-Form", GitHub, 2018. [Online]. Available: https://github.com/laur1s/PHP-Registration-Form. [Accessed: 03- Jun- 2018].
[4]"PHP: password_verify - Manual", Php.net, 2018. [Online]. Available: http://php.net/manual/en/function.password-verify.php. [Accessed: 04- Jun- 2018].
[5]"PHP: password_hash - Manual", Php.net, 2018. [Online]. Available: http://php.net/manual/en/function.password-hash.php. [Accessed: 04- Jun- 2018].
[6]"Free stock photos · Pexels", Pexels.com, 2018. [Online]. Available: https://www.pexels.com. [Accessed: 04- Jun- 2018].
